import React from "react";

export const metadata = {
  title: "Home",
};

const Homepage = () => {
  return <>eCom</>;
};

export default Homepage;
